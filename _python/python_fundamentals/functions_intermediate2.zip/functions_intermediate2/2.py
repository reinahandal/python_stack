students = [
        {'first_name':  'Michael', 'last_name' : 'Jordan'},
        {'first_name' : 'John', 'last_name' : 'Rosales'},
        {'first_name' : 'Mark', 'last_name' : 'Guillen'},
        {'first_name' : 'KB', 'last_name' : 'Tonel'}
    ]

def iterateDictionary(some_list):
    for i in range(0,len(some_list)):
        print("first_name - "+ some_list[i]['first_name']+ ", last_name - "+ some_list[i]['last_name'])
iterateDictionary(students)

